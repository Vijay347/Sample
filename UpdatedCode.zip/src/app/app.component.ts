
import { Component, NgModule, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router,ActivatedRoute, NavigationStart } from '@angular/router';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css'],
})

@NgModule({
  declarations: [AppComponent],

  imports: [],
  providers: [],
  bootstrap: [AppComponent]
})

export class AppComponent implements OnInit {
  form: FormGroup;
  private formSubmitAttempt: boolean;
  currentUrl: string = "";
  isMenuEnabled: boolean = false;
  

  constructor(
    private fb: FormBuilder,private router : Router
   
  ) {}

  ngOnInit() {

    this.router.events.subscribe((event)=>{
     if (event instanceof NavigationStart) {    
       console.log(event.url);
       if(event.url == '/')       
          this.isMenuEnabled = (event.url == '/') ? false : true;   
      else
        this.isMenuEnabled = (event.url == '/login') ? false : true; 
          
     }
    });

  
      this.form = this.fb.group({
      userName: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  isFieldInvalid(field: string) {
    return (
      (!this.form.get(field).valid && this.form.get(field).touched) ||
      (this.form.get(field).untouched && this.formSubmitAttempt)
    );
  }

  onSubmit() {
    if (this.form.valid) {
     
    }
    this.formSubmitAttempt = true;
  }
}