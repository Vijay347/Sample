import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { ILoginDetails,SignUpDetails,menuDetails } from '../../modules/common.identifier';
import { CommonService } from '../../services/common.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  

 loginUser :ILoginDetails [] =[{
    userName:"",
    password:""
  }]

menuDetails:menuDetails[]=[
{
    ID: 1,
    MenuName: "Nivetha",
    ShowName: "Nivetha Mani"    
},
{
    ID: 2,
    MenuName: "Nivetha",
    ShowName: "Nivetha Mani"    
},{
    ID: 3,
    MenuName: "Nivetha",
    ShowName: "Nivetha Mani"    
}]

   signupUser : SignUpDetails []=[{
    firstName:"",
    lastName:"",
    email:"",
    phone:"",
    password:"",
    confirmPassword:"" 
}]

  constructor( private router:Router,private commService: CommonService) { }
  
isLoginActive:boolean=true;
isSignUpActive:boolean=false;
isValidUser:boolean=false;
isValidSignUser:boolean=false;
invalidCheck:boolean =false;
invalidSignCheck:boolean =false;
response: any;
  items: any;
  ngOnInit() {

     this.commService.getMenuDetails().subscribe(data => {
      this.response = data;
      this.items = this.response.menuDetails
     // console.log(this.items);
    });

       this.commService.changeMessage(this.menuDetails); 
       console.log(this.menuDetails)
  }

  loginMenu()
  {
    this.isLoginActive=true;
    this.isSignUpActive=false;
  }

  signUpMenu()
  {
    this.isLoginActive=false;
    this.isSignUpActive=true;
  }

 loginSubmit(userLogin)
  {
  
  this.isValidUser = this.checkUserValid(userLogin);

  if(this.isValidUser)
  {
    this.router.navigateByUrl('/menu');  
    this.invalidCheck =false;     
  }
  else
  {
   // alert('not valid');
    this.invalidCheck =true;
  }  


  }

checkUserValid(userLogin){

    if(userLogin.userName!=undefined && userLogin.userName!='' &&userLogin.userName!=null && userLogin.passWord!=undefined && userLogin.passWord!='' &&userLogin.passWord!=null){
           return true;
      }
      else{
        this.invalidCheck =false;
          return false;
      }     

}


  signUpSubmit(signupUser)
  {
      
  this.isValidSignUser = this.checkSignUserValid(signupUser);

  if(this.isValidSignUser)
  {
    this.loginMenu();
    this.invalidSignCheck =false;     
  }
  else
  {
    //alert('not valid');
    this.invalidSignCheck =true;
  }  


  }

  checkSignUserValid(SignUserLogin){

    if(SignUserLogin.userName!=undefined && SignUserLogin.userName!='' &&SignUserLogin.userName!=null && SignUserLogin.passWord!=undefined && SignUserLogin.passWord!='' &&SignUserLogin.passWord!=null){
           return true;
      }
      else{
        this.invalidSignCheck =false;
          return false;
      }     

  }


}
