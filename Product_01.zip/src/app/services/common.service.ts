import { Injectable } from '@angular/core';
import { HttpClient,HttpHeaders } from '@angular/common/http';
import { catchError,distinctUntilChanged } from 'rxjs/operators';
import { Observable, Subject,BehaviorSubject } from 'rxjs';
import { menuDetails } from '../modules/common.identifier';


@Injectable()
export class CommonService {
  private subject = new Subject<any>();
  _subject = new Subject<any>();
  
  private menuDetails: menuDetails[] = [
    {
      ID: 0,
      MenuName: "",
      ShowName: ""
    }
  ];


  private _dataListSource: BehaviorSubject<menuDetails[]> = new BehaviorSubject([]);
  dataList: Observable<menuDetails[]> = this._dataListSource.asObservable();


  constructor(private http: HttpClient) { }


  changeMessage(message: menuDetails[]) {
    console.log(message);
    this._dataListSource.next(message);
  }



  getMenuDetails() {
    return this.http.get("../../assets/Json/menudetails.json");
  }


}
