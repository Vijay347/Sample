export interface ILoginDetails {
    userName?: string;
    password?: string;
   
} 

export interface SignUpDetails {
    firstName?: string;
    lastName?: string;
    email?: string;
    phone?: string;
    password?: string;
    confirmPassword?: string;
   
} 
export interface menuDetails{
    ID: number,
    MenuName: string,
    ShowName: string   

}