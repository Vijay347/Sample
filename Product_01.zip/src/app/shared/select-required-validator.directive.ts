import { Validator, AbstractControl, NG_VALIDATORS } from '@angular/forms';
import { Directive } from '@angular/core';
import { FormControlDirective,NgModel } from '@angular/forms';
// import { FORM_DIRECTIVES, ControlGroup, Control, FormBuilder } from '@angular/forms';


@Directive({

selector: '[ngModel][uppercase]',
providers: [NgModel],
host: {
    '(ngModelChange)' : 'onInputChange($event)',
    '(blur)': 'onBlur($event)'
      }
})
export class SelectRequiredValidatorDirective {


  onChange = (_) => { };
 private el: any;
 private newValue: any;

constructor(private model: NgModel) {
  this.el = model;
}

onInputChange(event) {
  this.newValue = event;
  //console.log(this.newValue);
}

 onBlur(event): { [key: string]: any } | null{
     console.log(this.newValue);
     console.log(this.model);
     //return { 'defaultSelected': true } : null;
    if(this.newValue==undefined || this.newValue=='' || this.newValue==null){
        console.log("true");
         console.log(this.model);
            return { 'defaultSelected': true };
    }
   //this.model.control.setValue(this.newValue.trim());   
 }

  
//   onInputChange(event){
//     var newValue = event.toUpperCase();
//     console.log(newValue);
//     this.model.valueAccessor.writeValue(newValue);
//     //this.model.viewToModelUpdate(newValue);
//   }


}