import { Component, OnInit, ElementRef, Renderer, ViewChildren, QueryList } from '@angular/core';
import { CommonService } from '../../services/common.service';
import { Subscription } from 'rxjs';
import { MDCFloatingLabel } from '@material/floating-label';
import { Router, ActivatedRoute } from '@angular/router';

// const floatingLabel = new MDCFloatingLabel(document.querySelector('.mdc-floating-label'));


@Component({
  selector: 'app-menu',
  templateUrl: './menu.component.html',
  styleUrls: ['./menu.component.css']
})


export class MenuComponent implements OnInit {
  response: any;
  items: any;
  newitems: any;
  message: any;
  subscription: Subscription;



  constructor(private router:Router,private commService: CommonService, private elementRef: ElementRef<any>) {
    // this.subscription = this.commService.getMessage().subscribe(message => { this.message = message; });
  }
  //floatingLabel = new MDCFloatingLabel(this.elementRef.nativeElement.querySelectorAll('.mdc-floating-label'));
  ngOnInit() {
    this.commService.dataList.subscribe(message => this.message = message)
    console.log(this.message);

    this.commService.getMenuDetails().subscribe(data => {
      this.response = data;
      this.items = this.response.menuDetails;
    });

  }


  showMenu = function () {
    this.newitems = this.elementRef.nativeElement.querySelectorAll('.circle a');
    console.log(this.newitems);
    for (var i = 0, l = this.newitems.length; i < l; i++) {
      this.newitems[i].style.left = (50 - 35 * Math.cos(-0.5 * Math.PI - 2 * (1 / l) * i * Math.PI)).toFixed(4) + "%";

      this.newitems[i].style.top = (50 + 35 * Math.sin(-0.5 * Math.PI - 2 * (1 / l) * i * Math.PI)).toFixed(4) + "%";
    }
    this.elementRef.nativeElement.querySelector('.circle').classList.toggle('open');
  }

    navigateMenu =function(menuID){
      console.log(menuID);
      this.router.navigateByUrl('/animalInfo');  
    }



}



