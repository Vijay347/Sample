import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-animal-info',
  templateUrl: './animal-info.component.html',
  styleUrls: ['./animal-info.component.css']
})
export class AnimalInfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
