import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './Login/login/login.component';
import { HeaderComponent } from './common/header/header.component';
import { FooterComponent } from './common/footer/footer.component';
import { MenuComponent } from './common/menu/menu.component';
import { AnimalInfoComponent } from './common/animal-info/animal-info.component';

const routes: Routes = [
      { path: '', redirectTo: 'login', pathMatch : 'full' },
      { path: 'login', component: LoginComponent,pathMatch : 'full' },    
      { path: 'menu', component: MenuComponent}, 
      { path: 'animalInfo', component: AnimalInfoComponent}, 
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
