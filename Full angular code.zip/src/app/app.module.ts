import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms'
import { AppComponent } from './app.component';
import { HttpClientModule } from '@angular/common/http';
import { FilterPipe } from './pipes/filter.pipe';
import { LoadingBarHttpClientModule } from '@ngx-loading-bar/http-client';
import { OrderModule, OrderPipe } from 'ngx-order-pipe';
import { LoginComponent } from './LoginPage/login/login.component'; // <-- Import OrderModule
import { Observable, Subject, ReplaySubject, from, of, range } from 'rxjs';
import { map, filter, switchMap } from 'rxjs/operators';
import { SlideMenuModule } from 'cuppa-ng2-slidemenu/cuppa-ng2-slidemenu';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CommonMenuComponent } from './components/common-menu/common-menu.component';
import { RouterModule } from '@angular/router';
import { NgxSpinnerModule } from 'ngx-spinner';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { CustomerDetailComponent } from './components/customer-detail/customer-detail.component';
import { CustomerCreationComponent } from './components/customer-creation/customer-creation.component';
import { PriceConfigComponent } from './components/price-config/price-config.component';
import { UpdateSalesComponent } from './components/update-sales/update-sales.component';
import { ProductDetailComponent } from './components/product-detail/product-detail.component';
import { ModalModule } from 'ngx-bootstrap/modal';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { NgbModalModule } from '@ng-bootstrap/ng-bootstrap';
import { MatAutocompleteModule, MatInputModule } from '@angular/material';
import { ILoginDetails,ICustomerDetails } from './models/common/common.component';
import { TypeaheadModule } from 'ngx-bootstrap';
import { ViewCustomerComponent } from './components/view-customer/view-customer.component';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';


@NgModule({
  declarations: [
    AppComponent,
    FilterPipe,
    LoginComponent,
    CommonMenuComponent,
    HeaderComponent,
    FooterComponent,
    CustomerDetailComponent,
    CustomerCreationComponent,
    PriceConfigComponent,
    UpdateSalesComponent,
    ProductDetailComponent,
    ViewCustomerComponent
    
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    LoadingBarHttpClientModule,
    ReactiveFormsModule,
    OrderModule,
    BrowserAnimationsModule,  
    NgxSpinnerModule,
    MatAutocompleteModule,
    MatInputModule,
    TypeaheadModule.forRoot(),
    NgbModalModule.forRoot(),
    ModalModule.forRoot(),
    RouterModule.forRoot([
      { path: '', redirectTo: 'login', pathMatch : 'full' },
      { path: 'login', component: LoginComponent,pathMatch : 'full' },
      { path: 'menu', component: CommonMenuComponent },
      { path: 'customerDetail', component: CustomerDetailComponent },
      { path: 'customerCreation', component: CustomerCreationComponent,data : {id : '0'} },
      { path: 'priceConfig', component: PriceConfigComponent },
      { path: 'updateSale', component: UpdateSalesComponent },
      { path: 'productDetail', component: ProductDetailComponent },
      { path: 'viewCustomer', component: ViewCustomerComponent,data : {id : '0'} }
      
     ]),
    TypeaheadModule.forRoot(),
    BsDatepickerModule.forRoot()
  ],
  
 
  providers: [OrderPipe,{provide: LocationStrategy, useClass: HashLocationStrategy}],
  bootstrap: [AppComponent]
})
export class AppModule { }
