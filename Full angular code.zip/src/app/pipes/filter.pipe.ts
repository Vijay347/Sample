import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filter'
})
export class FilterPipe implements PipeTransform {

  transform(value: any, args?: any): any {
    if (args.AllCustSearch) {
      value = value.filter(custList => custList.customerName.toLowerCase().indexOf(args.AllCustSearch.toLowerCase()) != -1);
    }

    if(args.StartDateSearch){
      value = value.filter((product) => {
       let Start_Date = product.creditedDate.substring(0,10).split('-');
        let startDateSearch =  this.converttoDate(args.StartDateSearch);
        var vStartDateSearch = startDateSearch.split('-')
      
       console.log(new Date(Start_Date[0],Start_Date[1]-1,Start_Date[2]) >= new Date(vStartDateSearch[0],startDateSearch[1]-1,startDateSearch[2]));
        return new Date(Start_Date[0],Start_Date[1]-1,Start_Date[2]) >= new Date(startDateSearch[0],startDateSearch[1]-1,startDateSearch[2]);
     });
   }
   if(args.EndDateSearch){
      value = value.filter((product) => {
       let End_Date = product.creditedDate.substring(0,10).split('-');
       let endDateSearch = args.EndDateSearch;
       return new Date(End_Date[0],End_Date[1]-1,End_Date[2]) <= new Date(endDateSearch[0],endDateSearch[1]-1,endDateSearch[2]);
     });
   }
    
    return value;

  }
  converttoDate =function(str) {
    var date = new Date(str),
        mnth = ("0" + (date.getMonth()+1)).slice(-2),
        day  = ("0" + date.getDate()).slice(-2);
    return [ date.getFullYear(), mnth, day ].join("-");
  }
}
