import { Binary } from "@angular/compiler";

export interface ILoginDetails {
    userName?: string;
    password?: string;

}
export interface ICustomerDetails {
    customerName?: string;
    phone?: number;
    address?: string;
    credit?: number;
    customerId?: number;
    areaId?:number;
}

export interface ICreditDetails {
    customerId?: number;
    customerDate?: string;
    credit?: number;
}

export interface IPriceDetails {
    typeId?: number;
    price?: number;
}

export interface IUpdatePriceDetails {
    customerId?: number;
    customerName?: string;
    date?: string;
    type?: string;
    qty50ml?: number;
    price50ml?: number;
    qty1L?: number;
    price1L?: number;
    totalprice50ML?: number;
    totalprice1L?: number;
    totalprice?: number;
}

export interface IAreaDetails {
    areaId?: number;
    areaName?: string;
    Name?:string;
}

export interface IUserCreation {
    userId?: number;
    userName?: string;
    password?:string;
    active?:number;
}