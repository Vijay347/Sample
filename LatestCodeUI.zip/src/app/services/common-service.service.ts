import { Component, NgModule, Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';


// var vURL = "http://localhost:63825/";
var vURL = "http://velloreshop.com/";
//  var vURL = "http://localhost:52071/";

// var vURL = "https://cors-anywhere.herokuapp.com/52071/api/";


const httpOptions = {
  headers: new HttpHeaders({
      'Access-Control-Allow-Origin':'*',
      'Access-Control-Allow-Credentials':'true',
      'Access-Control-Allow-Methods':'*',
      'Access-Control-Allow-Headers':'Origin, X-Requested-With, Content-Type, Accept',
      'Content-Type': 'application/json; charset=utf-8'
  })
};


@Injectable({
  providedIn: 'root'
})

export class CommonServiceService {

 
  constructor(public http: HttpClient) { }
 
  // Common Code

  callCommonService(inputDetails) {
    return this.http.post(vURL + "api/MilkManagement/Execute",inputDetails,httpOptions);
  }
  
  // getChartDetails(chartInput)
  // {
  //   //alert("Hi2");
  //   return this.http.post("https://cors-anywhere.herokuapp.com/cliniconway.com/Api/Sales/Execute",
  //    chartInput, 
  //    httpOptions);
  // };
}; 
