import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonServiceService } from '../../services/common-service.service';
import { OrderPipe, OrderModule } from 'ngx-order-pipe';
import { PagerService } from '../../services/pageService';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { IUpdatePriceDetails } from '../../models/common/common.component';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { debounceTime, distinctUntilChanged, map } from 'rxjs/operators';
import { TypeaheadModule } from 'ngx-bootstrap';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';


@Component({
  selector: 'app-update-sales',
  templateUrl: './update-sales.component.html',
  styleUrls: ['./update-sales.component.css']
})
export class UpdateSalesComponent implements OnInit {

  minDate: Date;
  maxDate: Date;
  today: Date;

  bsConfig: Partial<BsDatepickerConfig>;
  userRoleId: any;
  userId: any;

  constructor(private spinner: NgxSpinnerService, private appServices: CommonServiceService, private router: Router) {

    this.minDate = new Date();
    this.maxDate = new Date();
    this.today = new Date();
    this.minDate.setDate(this.minDate.getDate() - 15);

  }

  noResult = false;
  priceDetail: IUpdatePriceDetails = {
    customerId: 0,
    customerName: "",
    date: "",
    type: "",
    qty50ml: 0,
    qty1L: 0,
    price50ml: 0,
    price1L: 0,
    totalprice50ML: 0,
    totalprice1L: 0,
    totalprice: 0
  }

  savedDetail: any = [];
  customerDetails: any = [];
  customerList: any = [];

  change50MLCount: number = 0;
  change1LCount: number = 0;
  totalPrice: number = 0;
  ddlTypes: any = [];
  ddlTypesList: any = [];
  priceTypesList: any = [];
  showModal: boolean = false;

  custJson = [
    {
      "custDetailList": [
        {
          "customerId": 1,
          "customerName": "Vijay"
        },
        {
          "customerId": 2,
          "customerName": "Tej",
        },
        {
          "customerId": 3,
          "customerName": "Raj"
        },
        {
          "customerId": 4,
          "customerName": "Jayanth"
        }
      ],

    }

  ];

  ngOnInit() {
    this.userRoleId = localStorage.getItem('userRole');
    this.userId = localStorage.getItem('userId');
    
    var dynamicData = this.getCustomerName();
    var typeData = this.getType();
  }

  onSelect(ev) {
    this.priceDetail.customerId = ev.item.customerId;
  }

  public getCustomerName() {
    this.spinner.show();

    var vGetCustomer = {
      Action: "GetCustomerDetail"
    }

    // this.customerDetails=this.custJson[0];

    //     if(this.customerDetails !=null)
    //     {          
    //        this.customerList=this.customerDetails.custDetailList;
    //        this.spinner.hide();          
    //     }
    //     else{
    //       this.spinner.hide();
    //     } 

    this.appServices.callCommonService(vGetCustomer).subscribe(data => {
      this.customerDetails = data;

      if (this.customerDetails != null) {
        if (this.customerDetails.IsSuccess) {
          this.customerList = this.customerDetails.lstCustomerDetail;
          this.spinner.hide();
        }
        else
          this.spinner.hide();
      }
      else
        this.spinner.hide();

    });

  };


  priceSubmit(priceDetail) {
    debugger;
    this.spinner.show();

    if (priceDetail != undefined) {
      priceDetail.totalprice = priceDetail.totalprice50ML + priceDetail.totalprice1L;

      if (priceDetail.customerId != null && priceDetail.customerId != 0 &&
        priceDetail.date != null && priceDetail.date != '' &&
        priceDetail.totalprice != null && priceDetail.totalprice != 0) {
        var myDate = new Date(priceDetail.date).toLocaleString();

        var vSales = {
          Action: "AddSalesDetail",
          SaleModel:
            {
              customerId: priceDetail.customerId,
              createdDate: myDate,
              totalPrice: priceDetail.totalprice,
              qty50ML:priceDetail.qty50ML == "" ? 0 : priceDetail.qty50ML,
              qty1L:priceDetail.qty1L == "" ? 0 : priceDetail.qty1L,            
              price50ML:priceDetail.price50ml,
              price1L:priceDetail.price1L,
              totalprice50ML: priceDetail.totalprice50ML,
              totalprice1L: priceDetail.totalprice1L
            }
        };

        this.appServices.callCommonService(vSales).subscribe(data => {
          if (data) {
            this.savedDetail = data;

            if (this.savedDetail.IsSuccess) {
              Swal('success', `Sales details added successfully`, 'success');

              if (this.userRoleId == "1")
                this.router.navigateByUrl('/customerDetail');
              else {
                this.router.navigate(['/viewCustomer', { id: this.priceDetail.customerId }]);
              }

              this.spinner.hide();
            }
            else {
              Swal('Failed', 'Please try again..', 'error');
              this.spinner.hide();
            }

          }
          else {
            Swal('Failed', 'Please try again..', 'error');
            this.spinner.hide();
          }
        });
      }
      else {
        Swal('Failed', 'All fields are mandatory.', 'error');
        this.spinner.hide();
      }
    }
    else {
      Swal('Failed', 'All fields are mandatory.', 'error');
      this.spinner.hide();
    }
  }

  typeaheadNoResults(event: boolean): void {
    this.noResult = event;
  }

  on50MLTextChange(txtValue) {
    this.priceDetail.totalprice50ML = this.priceDetail.price50ml * txtValue;
  }

  on1LTextChange(txtValue) {
    this.priceDetail.totalprice1L = this.priceDetail.price1L * txtValue;
  }

  public getType() {
    this.spinner.show();

    var vGetTypes = {
      Action: "GetTypeDetail"
    }

    // this.ddlTypes=this.priceJson[0];

    //     if(this.ddlTypes !=null)
    //     {          
    //         this.ddlTypesList=this.ddlTypes.typeList;
    //         this.priceTypesList=this.ddlTypes.priceList;
    //        this.spinner.hide();          
    //     }
    //     else{
    //       this.spinner.hide();
    //     } 

    this.appServices.callCommonService(vGetTypes).subscribe(data => {

      this.ddlTypes = data;

      if (this.ddlTypes != null) {
        if (this.ddlTypes.IsSuccess) {
          this.ddlTypesList = this.ddlTypes.lstTypeDetail;
          this.priceTypesList = this.ddlTypes.lstPriceDetail;

          let vList = this.priceTypesList;

          for (let i = 0; i < vList.length; i++) {
            if (vList[i].typeName == "0.5L") {
              this.priceDetail.price50ml = vList[i].price;
            }
            else {
              this.priceDetail.price1L = vList[i].price;
            }
          }
          this.spinner.hide();
        }
        else {
          this.spinner.hide();
        }
      }
      else
        this.spinner.hide();
    });

  };

}
