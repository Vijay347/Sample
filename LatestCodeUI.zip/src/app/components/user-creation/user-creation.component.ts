import { Component, OnInit } from '@angular/core';
import Swal from 'sweetalert2';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonServiceService } from '../../services/common-service.service';
import { Router, ActivatedRoute } from '@angular/router';
import { IUserCreation } from '../../models/common/common.component';

@Component({
  selector: 'app-user-creation',
  templateUrl: './user-creation.component.html',
  styleUrls: ['./user-creation.component.css']
})
export class UserCreationComponent implements OnInit {
  
  
  userCreate: IUserCreation = {
    userId: 0,
    userName: "",
    password:"",
    active: 0
    
  }

  constructor(private spinner: NgxSpinnerService, private appServices: CommonServiceService, private router: Router, private activatedRoute: ActivatedRoute) {


  }
  ddlArea: any = [];
  ddlAreaList: any = [];
  customerDetails: any = [];
  customerList: any = [];
  customerID: string = '0';
  resultDetails: any = [];
  userLoginId: any;

  ngOnInit() {

    this.customerID = this.activatedRoute.snapshot.paramMap.get('id');
    this.userLoginId = localStorage.getItem('userId');

    this.getArea();

    // if (this.customerID != '0')
    //   this.getCustDetails(this.customerID);
    // else
    //   this.getCustDetails(0);
  }

  onlyNumberKey(event) {
    return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode >= 48 && event.charCode <= 57;
  }

  onlyDecimalNumberKey(event) {
    let charCode = (event.which) ? event.which : event.keyCode;
    if (charCode != 46 && charCode > 31
      && (charCode < 48 || charCode > 57))
      return false;
    return true;
  }

  customerSubmit(custDetail) {
    
    this.spinner.show();

    if (custDetail.customerName != null && custDetail.customerName != "" && custDetail.areaId != 0) {
      if (custDetail.phone.length != 10) {
        Swal('Failed', 'Phone number should be 10 digits', 'error');
        this.spinner.hide();
      }
      else {

        var vCustForm = {
          Action: "AddCustomer",
          CustomerDetail:
            {
              customerId: this.customerID,
              customerName: custDetail.customerName,
              phone: custDetail.phone,
              address: custDetail.address,
              credit: 0,
              areaId: custDetail.areaId,
              userId: this.userLoginId
            }
        };

        this.appServices.callCommonService(vCustForm).subscribe(data => {
          if (data) {
            this.resultDetails = data;
            if (this.resultDetails.IsSuccess) {
              Swal('success', `Customer details submitted successfully`, 'success');
              this.router.navigateByUrl('/customerDetail');
              this.spinner.hide();
            }
            else {
              Swal('Failed', this.resultDetails.Message, 'error');
              this.spinner.hide();
            }
          }
          else {
            Swal('Failed', 'Please try again..', 'error');
            this.spinner.hide();
          }
        });

      }
    }
    else {
      Swal('Failed', 'All fields are mandatory.', 'error');
      this.spinner.hide();
    }
  };

  BackCustomer() {
    this.router.navigateByUrl('/customerDetail');
  }

  // getCustDetails(custID) {
  //   this.spinner.show();

  //   if (custID != 0) {
  //     var vGetCustomer = {
  //       Action: "GetCustomerDetail"
  //     }

  //     // this.customerDetails=this.custJson[0];

  //     // if(this.customerDetails !=null)
  //     // { 
  //     //   let vList =this.customerDetails.custDetailList;
  //     //   for (let i = 0; i < vList.length; i++) {
  //     //     if (vList[i].customerId == custID) {
  //     //         this.customerList= vList[i];
  //     //         this.custDetail=this.customerList;
  //     //     }
  //     // } 

  //     //     this.spinner.hide();          
  //     // }
  //     // else{
  //     //   this.spinner.hide();
  //     // } 

  //     this.appServices.callCommonService(vGetCustomer).subscribe(data => {
  //       this.customerDetails = data;
  //       if (this.customerDetails != null) {
  //         if (this.customerDetails.IsSuccess) {
  //           let vList = this.customerDetails.lstCustomerDetail;
  //           for (let i = 0; i < vList.length; i++) {
  //             if (vList[i].customerId == custID) {
  //               this.customerList = vList[i];
  //               this.custDetail = this.customerList;
  //               this.custDetail.credit = this.customerList.balance
  //             }
  //           }
  //           // this.customerList=this.customerDetails.customerList;
  //           this.spinner.hide();
  //         }
  //         else
  //           this.spinner.hide();
  //       }
  //       else
  //         this.spinner.hide();
  //     });
  //   }
  //   else {

  //     this.custDetail.customerId = 0;
  //     this.custDetail.customerName = "";
  //     this.custDetail.address = "";
  //     this.custDetail.phone = 0;
  //     this.custDetail.credit = 0;

  //     this.custDetail = this.custDetail;
  //     this.spinner.hide();
  //   }

  // };


  public getArea() {
    this.spinner.show();

    var vGetArea = {
      Action: "GetAreaDetail"
    }

    this.appServices.callCommonService(vGetArea).subscribe(data => {

      this.ddlArea = data;

      if (this.ddlArea != null) {
        if (this.ddlArea.IsSuccess) {
          this.ddlAreaList = this.ddlArea.lstAreaDetail;
          this.spinner.hide();
        }
        else {
          this.spinner.hide();
        }
      }
      else
        this.spinner.hide();
    });

  };

};