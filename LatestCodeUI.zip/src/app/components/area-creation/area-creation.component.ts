import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonServiceService } from '../../services/common-service.service';
import { OrderPipe, OrderModule } from 'ngx-order-pipe';
import { PagerService } from '../../services/pageService';
import Swal from 'sweetalert2';
import { IAreaDetails } from '../../models/common/common.component';


@Component({
  selector: 'app-area-creation',
  templateUrl: './area-creation.component.html',
  styleUrls: ['./area-creation.component.css']
})
export class AreaCreationComponent implements OnInit {

  areaDetail: IAreaDetails[] = [{
    areaId: 0,
    areaName: "",
    Name: ""
  }]

  constructor(private spinner: NgxSpinnerService, private appServices: CommonServiceService) { }

  resultDetails: any;
  areaDetails: any;
  nameVerified: boolean = true;

  ngOnInit() {
    this.getArea();
  }


  public areaSubmit(addAreaDetail) {
    this.spinner.show();
    this.nameVerified=true;

    if (addAreaDetail.Name != undefined && addAreaDetail.Name != null && addAreaDetail.Name != "") {

      for (let ad of this.areaDetails) {

        if (ad.areaName.toLowerCase() == addAreaDetail.Name.toLowerCase()) {
          this.nameVerified = false;
        }
      }

      if (this.nameVerified) {

        var vCustForm = {
          Action: "AddArea",
          AreaDetail:
            {
              areaId: addAreaDetail.areaId,
              areaName: addAreaDetail.Name
            }
        };

        this.appServices.callCommonService(vCustForm).subscribe(data => {
          this.resultDetails = data;
          if (this.resultDetails.IsSuccess) {
            Swal('success', `Area detail submitted successfully...`, 'success');
            this.getArea();
            this.areaDetail = [];
            this.spinner.hide();
          } else {
            Swal('Failed', 'Please try again..', 'error');
            this.spinner.hide();
          }
        });
      }
      else {
        Swal('Failed', 'AreaName already exists.', 'error');
        this.spinner.hide();
      }
    }
    else {
      Swal('Failed', 'All fields are mandatory.', 'error');
      this.spinner.hide();
    }
  };


  public getArea() {
    this.spinner.show();

    var vGetArea = {
      Action: "GetAreaDetail"
    }

    this.appServices.callCommonService(vGetArea).subscribe(data => {

      this.resultDetails = data;

      if (this.resultDetails != null) {
        if (this.resultDetails.IsSuccess) {
          this.areaDetails = this.resultDetails.lstAreaDetail;
          this.spinner.hide();
        }
        else {
          this.spinner.hide();
        }
      }
      else
        this.spinner.hide();
    });

  };

  editClick(list) {
    this.areaDetail = list;
  };

  public clearArea() {
    this.areaDetail = [];
  }

}
