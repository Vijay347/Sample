import { Component, OnInit, Injectable } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonServiceService } from '../../services/common-service.service';
import { OrderPipe, OrderModule } from 'ngx-order-pipe';
import { PagerService } from '../../services/pageService';
import { NgbModalConfig, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import Swal from 'sweetalert2';
import { ICreditDetails, ICustomerDetails } from '../../models/common/common.component';
import { Router, ActivatedRoute } from '@angular/router';
import { BsDatepickerConfig } from 'ngx-bootstrap/datepicker';

@Component({
  selector: 'app-customer-detail,demo-datepicker-color-theming',
  templateUrl: './customer-detail.component.html',
  styleUrls: ['./customer-detail.component.css'],
  providers: [PagerService, NgbModalConfig, NgbModal],

})

@Injectable()
export class CustomerDetailComponent implements OnInit {

  minDate: Date;
  maxDate: Date;
  today: Date;

  bsConfig: Partial<BsDatepickerConfig>;


  custDetail: ICreditDetails = {
    customerId: 0,
    customerDate: "",
    credit: 0
  }

  editCustDetail: ICustomerDetails = {
    customerId: 0,
    customerName: "",
    phone: 0,
    address: "",
    credit: 0
  }

  constructor(
    config: NgbModalConfig,
    private modalService: NgbModal,
    private spinner: NgxSpinnerService,
    private appServices: CommonServiceService,
    private pageService: PagerService,
    private router: Router,
    private activeRoute: ActivatedRoute) {
    config.backdrop = 'static';
    config.keyboard = false;

    this.minDate = new Date();
    this.maxDate = new Date();
    this.today = new Date();
    this.minDate.setDate(this.minDate.getDate() - 15);

  }
  customerDetails: any = [];
  customerList: any = [];
  search: any = {
    custSearch: ''
  }

  isHeaderMenuEnabled: boolean = false;
  showModal: boolean = false;
  ddlArea: any = [];
  ddlAreaList: any = [];

  custJson = [
    {
      "custDetailList": [
        {
          "customerId": 1,
          "customerName": "Vijay",
          "phone": 11122,
          "credit": 100,
          "balance": 50,
          "address": "test"
        },
        {
          "customerId": 2,
          "customerName": "Tej",
          "phone": 444,
          "credit": 10,
          "balance": 10,
          "address": "test1"
        }
      ],
    }
  ];

  ngOnInit() {

    let roleId = localStorage.getItem('userRole');
    this.isHeaderMenuEnabled = roleId == "1" ? true : false;

    const routeParams = this.activeRoute.snapshot.params;
    var dynamicData = this.getCustDetails();
    this.getArea();
  }


  getCustDetails() {
    this.spinner.show();

    var vGetCustomer = {
      Action: "GetCustomerDetail"
    }

    // this.customerDetails=this.custJson[0];

    // if(this.customerDetails !=null)
    // {          
    //     this.customerList=this.customerDetails.custDetailList;
    //    this.spinner.hide();          
    // }
    // else{
    //   this.spinner.hide();
    // } 



    // this.appServices.getCustDetails().subscribe(data => {
    this.appServices.callCommonService(vGetCustomer).subscribe(data => {
      this.customerDetails = data;

      if (this.customerDetails != null) {
        if (this.customerDetails.IsSuccess) {
          this.customerList = this.customerDetails.lstCustomerDetail;
          this.spinner.hide();
        }
        else
          this.spinner.hide();
      }
      else
        this.spinner.hide();
    });

  };

  creditClick(list, content) {

    //  var vCustForm = {
    //           customerId: 1,
    //           creditedDate: this.today,         
    //           credit: 600         
    //         };

    //  var vCustForm = {
    //     customerId: list.customerId,
    //     creditedDate: list.creditedDate.slice(0,-9),         
    //     Amount: list.credit         
    //   };


    if (list.creditedDate.length > 0)
      list.creditedDate = this.today;

    // list.credit=list.balance;
    list.credit = 0;
    this.custDetail = list;

    this.modalService.open(content, { centered: true });
  };

  creditSubmit(custDetail, contentModal) {
    if (custDetail.creditedDate != null && custDetail.creditedDate != "") {
      if (custDetail.credit > 0) {
        var myDate = new Date(custDetail.creditedDate).toLocaleString();

        var vCustForm = {
          Action: "AddCustomer",
          CustomerDetail:
            {
              customerId: custDetail.customerId,
              creditedDate: custDetail.creditedDate,
              credit: custDetail.credit,
              reason: 'update'
            }
        };

        this.appServices.callCommonService(vCustForm).subscribe(data => {
          if (data) {
            Swal('success', `Customer details updated successfully...`, 'success');
            this.getCustDetails();
          }
          else {
            Swal('Failed', 'Please try again..', 'error');
          }
        });

        this.modalService.dismissAll();
      }
      else {
        Swal('Failed', 'Please enter credit amount', 'error');
      }

    }
    else {
      Swal('Failed', 'All fields are mandatory.', 'error');
    }

  };


  editClick(custDetail) {
    this.editCustDetail = custDetail;

    this.router.navigate(['/customerCreation', { id: this.editCustDetail.customerId }]);
  }

  viewClick(custDetail) {
    this.editCustDetail = custDetail;

    this.router.navigate(['/viewCustomer', { id: this.editCustDetail.customerId }]);
  }

  createCustomer() {
    this.router.navigate(['/customerCreation', { id: 0 }]);
  }

  public getArea() {
    this.spinner.show();

    var vGetArea = {
      Action: "GetAreaDetail"
    }

    this.appServices.callCommonService(vGetArea).subscribe(data => {

      this.ddlArea = data;

      if (this.ddlArea != null) {
        if (this.ddlArea.IsSuccess) {
          this.ddlAreaList = this.ddlArea.lstAreaDetail;
          this.spinner.hide();
        }
        else {
          this.spinner.hide();
        }
      }
      else
        this.spinner.hide();
    });

  };

};



