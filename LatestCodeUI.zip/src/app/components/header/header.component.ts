import { Component, OnInit, NgModule, Input } from '@angular/core';
import { Router, ActivatedRoute, NavigationStart } from '@angular/router';
import { LoginComponent } from '../../LoginPage/login/login.component';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  isHeaderMenuEnabled: boolean = false;

  constructor(private router: Router) {

  }

  ngOnInit() {
    let roleId = localStorage.getItem('userRole');
    this.isHeaderMenuEnabled = roleId == "1" ? true : false;
  }

  customerDetail() {
    this.router.navigate(['/customerDetail']);
  }

  createCustomer() {
    this.router.navigate(['/customerCreation', { id: 0 }]);
  }

  areaCreation() {
    this.router.navigate(['/areaCreation']);
  }

  areaUserCreation() {
    this.router.navigate(['/areaDetail']);
  }

  userCreation() {
    this.router.navigate(['/userCreation']);
  }

  viewAll() {
    this.router.navigate(['/productDetail']);
  }

  priceConfig() {
    this.router.navigate(['/priceConfig']);
  }

  manageSale() {
    this.router.navigate(['/updateSale']);
  }
 
}
