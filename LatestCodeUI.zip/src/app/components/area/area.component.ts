import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonServiceService } from '../../services/common-service.service';
import { OrderPipe, OrderModule } from 'ngx-order-pipe';
import { PagerService } from '../../services/pageService';
import Swal from 'sweetalert2';
import { IAreaDetails } from '../../models/common/common.component';

@Component({
  selector: 'app-area',
  templateUrl: './area.component.html',
  styleUrls: ['./area.component.css']
})
export class AreaComponent implements OnInit {

  areaDetail: IAreaDetails[] = [{
    areaId: 0,
    areaName: ""
  }]

  constructor(private spinner: NgxSpinnerService, private appServices: CommonServiceService) { }

  ddlArea: any = [];
  ddlAreaList: any = [];
  resultDetails: any = [];
  customerList: any = [];
  selectedArea: string = "";
  isEnabled: boolean = false;
  masterSelected: boolean;
  checkedList: any;

  ngOnInit() {

    this.getArea();
  }


  public getArea() {
    this.spinner.show();

    var vGetArea = {
      Action: "GetAreaDetail"
    }

    this.appServices.callCommonService(vGetArea).subscribe(data => {

      this.ddlArea = data;

      if (this.ddlArea != null) {
        if (this.ddlArea.IsSuccess) {
          this.ddlAreaList = this.ddlArea.lstAreaDetail;
          this.spinner.hide();
        }
        else {
          this.spinner.hide();
        }
      }
      else
        this.spinner.hide();
    });

  };

  public areaChange(selectedValue) {
    this.spinner.show();
    this.selectedArea = selectedValue;
    var vGetArea = {
      Action: "GetCustomerBasedOnArea",
      AreaDetail:
        {
          areaId: this.selectedArea
        }
    };

    this.appServices.callCommonService(vGetArea).subscribe(data => {
      this.resultDetails = data;

      if (this.resultDetails != null) {
       
        if (this.resultDetails.IsSuccess) {
          this.customerList = this.resultDetails.lstCustomerDetail;
          this.isEnabled = true;
          this.spinner.hide();
        }
        else {
          this.customerList=[];
          this.isEnabled = false;
          this.spinner.hide();
        }
      }
      else
      {
        this.customerList=[];
          this.isEnabled = false;
          this.spinner.hide();
      }
    });

  };


  public areaSubmit(selectedName) {
    //this.selectedArea
    console.log(selectedName);
  }

  public checkUncheckAll() {
    for (var i = 0; i < this.customerList.length; i++) {
      this.customerList[i].isSelected = this.masterSelected;
    }
    this.getCheckedItemList();
  }
  public isAllSelected() {
    this.masterSelected = this.customerList.every(function (item: any) {
      return item.isSelected == true;
    })
    this.getCheckedItemList();
  }

  public getCheckedItemList() {
    this.checkedList = [];
    for (var i = 0; i < this.customerList.length; i++) {
      if (this.customerList[i].isSelected)
        this.checkedList.push(this.customerList[i]);
    }
    this.checkedList = JSON.stringify(this.checkedList);

    console.log(this.checkedList);
  }
}
