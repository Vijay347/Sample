import { Component, NgModule, Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';


var vURL = "http://localhost:63825/";
// var vURL = "http://velloreshop.com/";
//  var vURL = "http://localhost:52071/";

// var vURL = "https://cors-anywhere.herokuapp.com/52071/api/";


const httpOptions = {
  headers: new HttpHeaders({
      'Access-Control-Allow-Origin':'*',
      'Access-Control-Allow-Credentials':'true',
      'Access-Control-Allow-Methods':'*',
      'Access-Control-Allow-Headers':'Origin, X-Requested-With, Content-Type, Accept',
      'Content-Type': 'application/json; charset=utf-8'
  })
};


@Injectable({
  providedIn: 'root'
})

export class CommonServiceService {

 
  constructor(public http: HttpClient) { }
 
  // Common Code

  callCommonService(inputDetails) {
    return this.http.post(vURL + "api/MilkManagement/Execute",inputDetails,httpOptions);
  }

  getLoginDetails(vlogin) {
    return this.http.post(vURL + "Login/Execute",vlogin,httpOptions);
  }

  getCustDetails() {
    return this.http.get(vURL + "Customer/GetCustomerDetails",httpOptions);
  }

  getSpecificCustDetail(customer) {
    return this.http.post(vURL + "Customer/GetSpecificCustomerDetails",customer,httpOptions);
  }

  // Submit customer code
  submitCustomer(project) {
    return this.http.post(vURL + "Customer/AddCustomerDetails", project, httpOptions);
  }

  getTypes() {
    return this.http.get(vURL + "Common/GetTypeDetail",httpOptions);
  }

  
  // Submit customer code
  submitPrice(price) {
    return this.http.post(vURL + "Common/AddPrice", price, httpOptions);
  }

  getProductDetail() {
    return this.http.get(vURL + "Customer/GetProductDetail",httpOptions);
  }

  submitSales(Sales) {
    return this.http.post(vURL + "Sales/AddSalesDetail", Sales, httpOptions);
  }

  // getChartDetails(chartInput)
  // {
  //   //alert("Hi2");
  //   return this.http.post("https://cors-anywhere.herokuapp.com/cliniconway.com/Api/Sales/Execute",
  //    chartInput, 
  //    httpOptions);
  // };
}; 
