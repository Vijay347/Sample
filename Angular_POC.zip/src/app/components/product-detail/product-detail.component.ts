import { Component, OnInit } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { CommonServiceService } from '../../services/common-service.service'; 
import { OrderPipe, OrderModule } from 'ngx-order-pipe';
import { PagerService } from  '../../services/pageService';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {

  list:any= []; 
  productList:any=[]; 
  filterList:any=[]; 
  search: any = {
    custSearch: '',
    startDate:'',
    endDate:''
  }
  constructor(private spinner: NgxSpinnerService,private appServices: CommonServiceService) { }

  ngOnInit() {
    var vlist = this.getProductDetail();
  }


  public getProductDetail()
  {
    this.spinner.show();   

    var vGetProduct = { 
      Action: "GetProduct"    
   }

    this.appServices.callCommonService(vGetProduct).subscribe(data => {
                     
      this.list = data;

        if(this.list !=null)
        {
          if(this.list.IsSuccess)
          {
            this.productList=this.list.lstCustomerDetail;
            this.filterList= this.productList;
            this.spinner.hide();
          } 
          else{
            this.spinner.hide();   
          }
        } 
        else
        this.spinner.hide();     
      }); 
      
  };


  public dateSubmit(selectedDate)
  {
    this.spinner.show();   

    if(selectedDate.startDate!=null && selectedDate.startDate!="" && 
        selectedDate.endDate!=null && selectedDate.endDate!="")
    {
      this.filterList= this.productList;

      let startDateSearch = selectedDate.startDate.toLocaleDateString();
      let endDateSearch = selectedDate.endDate.toLocaleDateString();
      
      this.filterList = this.filterList.filter(m => new Date(m.creditedDate) >= new Date(startDateSearch) 
                    && new Date(m.creditedDate) <= new Date(endDateSearch));
    
    }
    this.spinner.hide();     
  };
}

