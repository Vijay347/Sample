import { Component, OnInit,NgModule,Input  } from '@angular/core';
import { Router,ActivatedRoute, NavigationStart } from '@angular/router';
import { LoginComponent,AppGlobals } from '../../LoginPage/login/login.component';


@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
  
})
export class HeaderComponent implements OnInit {

  isHeaderMenuEnabled: boolean = false;

  constructor(private router : Router, private globalValue: AppGlobals) { }

  ngOnInit() {

    this.isHeaderMenuEnabled = (this.globalValue.isRoleId == 1)?true : false;
    alert(this.isHeaderMenuEnabled);
    }

  

}
